
public abstract class Helicopter implements Plane, Takeoff {
	
	public void Verticaltakeoff() {
		
	}
	public void SubSonicFly() {
		
	}

}