
public  class AirPlane implements Plane, Takeoff {
	
	public void LongDistanceTakeOff() {
		
	}
	public void SubSonicFly() {
		
	}

}
