
public abstract class Fighter implements Plane, Takeoff {
	
	public void LongDistanceTakeOff() {
		
	}
	public void SuperSonicFly() {
		
	}

}