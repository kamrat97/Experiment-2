
public interface Takeoff {

	public void SubSonicFly();
	public void SuperSonicFly();
		
	
}
