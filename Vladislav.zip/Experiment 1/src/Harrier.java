
public abstract class Harrier implements Plane, Takeoff {
	
	public void Verticaltakeoff() {
		
	}
	public void SuperSonicFly() {
		
	}

}