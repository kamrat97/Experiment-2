
public interface Plane {
	
	public void VerticalTakeOff();
	public void LongDistanceTakeOff();

}
