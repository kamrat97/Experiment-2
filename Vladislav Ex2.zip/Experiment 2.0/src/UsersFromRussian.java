
public class UsersFromRussian implements Users {

	public void update(int price) {
		System.out.println("Message for Russian StockA Price="+ price);
		System.out.println("Message for Russian StockB Price="+ price);
	}

	

}
